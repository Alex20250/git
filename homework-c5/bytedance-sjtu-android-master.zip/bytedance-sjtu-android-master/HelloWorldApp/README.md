## Chapter 1 Coursework

+ 创建一个MainActivity，关联的布局包含一个EditText和Button
+ 通过Button单击事件，EditText中的内容会以日志打印
+ 打包生成app-debug.apk

![img](folder/screenShot.png)

