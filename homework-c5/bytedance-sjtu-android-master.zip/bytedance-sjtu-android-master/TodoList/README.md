### Chapter 6 Coursework

一个UI简化版的Todolist App：

- 以DB形式实现对数据的存储
- checkbox选中状态可以点击实现条目的删除
- menu菜单提供了增加条目的功能
- 条目增加Activity对输入数据合法性进行简单校验，并对输入进行trim处理

![img1](folder/img1.png)

![img2](folder/img2.png)

![img3](folder/img3.png)

![img4](folder/img4.png)

