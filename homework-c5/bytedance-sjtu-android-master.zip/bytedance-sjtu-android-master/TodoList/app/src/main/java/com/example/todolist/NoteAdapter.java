package com.example.todolist;

import android.graphics.Paint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.todolist.bean.Note;

import java.text.SimpleDateFormat;
import java.util.*;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private List<Note> notes;
    private CB cb;


    public NoteAdapter(List<Note> notes, CB cb) {
        this.notes = notes;
        this.cb = cb;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        NoteViewHolder holder = new NoteViewHolder(view);
        holder.setCb(cb);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        holder.bind(notes.get(position));
    }

    public void update(List<Note> n) {
        notes.clear();
        notes.addAll(n);
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        return notes.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {

        private static final SimpleDateFormat SIMPLE_DATE_FORMAT =
                new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss", Locale.ENGLISH);

        private TextView text;
        private TextView date;
        private ImageView imageView;
        private CheckBox checkBox;
        private CB cb;
        private Note note;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.content);
            date = itemView.findViewById(R.id.date);
            checkBox = itemView.findViewById(R.id.checkbox);
            imageView = itemView.findViewById(R.id.remove);

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        imageView.setVisibility(View.VISIBLE);
                        text.setAlpha(0.5f);
                        note.setCheck(true);
                        cb.update(note.getId(), true);
                    } else {
                        imageView.setVisibility(View.INVISIBLE);
                        text.setAlpha(1.0f);
                        note.setCheck(false);
                        cb.update(note.getId(), false);
                    }
                }
            });

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cb.remove(note.getId());
                }
            });
        }

        public void setCb(CB cb) {
            this.cb = cb;
        }

        public void bind(Note note) {
            this.note = note;
            text.setText(note.getText());
            date.setText(SIMPLE_DATE_FORMAT.format(note.getDate()));

            if (note.isCheck()) {
                imageView.setVisibility(View.VISIBLE);
                text.setAlpha(0.5f);
                checkBox.setChecked(true);
            } else {
                imageView.setVisibility(View.INVISIBLE);
                text.setAlpha(1.0f);
                checkBox.setChecked(false);
            }

            Log.d("TAG", note.toString());
        }
    }
}
