package com.example.todolist;

public interface CB {
    public void remove(int id);
    public void update(int id, boolean checked);
}
