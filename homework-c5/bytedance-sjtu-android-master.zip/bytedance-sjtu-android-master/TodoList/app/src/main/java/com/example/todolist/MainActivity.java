package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.todolist.bean.Note;

import java.util.*;


public class MainActivity extends AppCompatActivity implements CB {

    private SQLiteOpenHelper helper;
    private SQLiteDatabase db;
    private NoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helper = new TodoDbHelpter(this, TodoDbHelpter.DBNAME, null, 1);
        db = helper.getReadableDatabase();

        List<Note> notes = queryFromDb();

        RecyclerView view = findViewById(R.id.view);
        view.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(notes, this);
        view.setAdapter(adapter);
        view.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private List<Note> queryFromDb() {
        List<Note> notes = new ArrayList<>();
        Cursor cursor = db.query("Notes", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String text = cursor.getString(cursor.getColumnIndex("content"));
                int date = cursor.getInt(cursor.getColumnIndex("date"));
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                int state = cursor.getInt(cursor.getColumnIndex("state"));
                Note n = new Note(id, text, new Date(date), state == 1);
                notes.add(n);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return notes;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        db.close();
        helper.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    private void insert(String text) {
        ContentValues values = new ContentValues();
        values.put("content", text);
        values.put("date", System.currentTimeMillis());
        values.put("state", 0);
        long res = db.insert("Notes", null, values);
        if (res != -1) {
            adapter.update(queryFromDb());
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_item:
                Intent intent = new Intent(MainActivity.this, ItemActivity.class);
                startActivityForResult(intent, 1);
                break;
            default:
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("TAG", "here");
        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    String text = data.getStringExtra("text");
                    insert(text);
                }
            default:
        }
    }

    @Override
    public void remove(int id) {
        int res = db.delete("Notes", "id = ?", new String[] { String.valueOf(id)});
        if (res > 0) {
            adapter.update(queryFromDb());
        }
    }

    @Override
    public void update(int id, boolean checked) {
        ContentValues values = new ContentValues();
        values.put("state", checked ? 1 : 0);
        db.update("Notes", values, "id = ?", new String[] {String.valueOf(id)});
    }
}