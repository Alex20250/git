package com.example.todolist;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class TodoDbHelpter extends SQLiteOpenHelper {
    private static final String CREATE_TBL = "create table Notes ("
                                            + "id integer primary key autoincrement,"
                                            + "content text,"
                                            + "state integer,"
                                            + "date integer)";
    public static final String DBNAME = "notes.db";

    public TodoDbHelpter(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TBL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
