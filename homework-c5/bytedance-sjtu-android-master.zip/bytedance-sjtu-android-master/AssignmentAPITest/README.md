### Chapter 5 Coursework

- 发布视频API跑通
- 拉取视频API跑通

注：测试于API24