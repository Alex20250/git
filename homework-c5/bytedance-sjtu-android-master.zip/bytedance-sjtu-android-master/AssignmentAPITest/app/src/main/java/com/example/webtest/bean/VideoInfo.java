package com.example.webtest.bean;

import java.util.*;

public class VideoInfo {
    private List<Info> feeds;
    private boolean success;

    @Override
    public String toString() {
        return success ? "VideoInfo[details]:\n" + feeds.toString() : "request failed";
    }
}
