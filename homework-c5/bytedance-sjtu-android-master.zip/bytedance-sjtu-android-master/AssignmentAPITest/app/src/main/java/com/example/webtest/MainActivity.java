package com.example.webtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.webtest.bean.VideoInfo;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Multipart;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final String baseUrl = "https://api-sjtu-camp.bytedance.com/invoke/";

    private Retrofit retrofit = new Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create()).build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.upload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UploadService uploadService = retrofit.create(UploadService.class);
                List<MultipartBody.Part> parts = new ArrayList<>();
                parts.add(getMultiPartFromAsset("cover_image", "pic.png"));
                parts.add(getMultiPartFromAsset("video", "video.mp4"));
                uploadService.upload("id_1", "lly", parts).enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        Log.d(TAG, "response info: " + response.toString());
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.d(TAG, "operation failed: ", t);
                    }
                });
            }
        });


        findViewById(R.id.download).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadService downloadService = retrofit.create(DownloadService.class);
                downloadService.download().enqueue(new Callback<VideoInfo>() {
                    @Override
                    public void onResponse(Call<VideoInfo> call, Response<VideoInfo> response) {
                        Log.d(TAG, "response info: " + response.toString());
                        Log.d(TAG, response.body().toString());
                    }

                    @Override
                    public void onFailure(Call<VideoInfo> call, Throwable t) {
                        Log.d(TAG, "operation failed: ", t);
                    }
                });

            }

        });
    }

    private MultipartBody.Part getMultiPartFromAsset(String key, String name) {
        RequestBody body = RequestBody.create(MediaType.parse("multipart/form-data"), fileNameToByte(name));
        return MultipartBody.Part.createFormData(key, name, body);
    }

    private byte[] fileNameToByte(String name) {
        final AssetManager manager = getAssets();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        InputStream is = null;
        byte[] buffer = new byte[1024];
        int n;
        byte[] ret = null;
        try {
            is = manager.open(name);
            while (-1 != (n = is.read(buffer))) {
                bos.write(buffer, 0, n);
            }
            ret = bos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }
}


