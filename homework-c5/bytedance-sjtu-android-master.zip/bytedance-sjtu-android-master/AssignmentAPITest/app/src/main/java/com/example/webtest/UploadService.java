package com.example.webtest;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import java.util.*;

public interface UploadService {

    @Multipart
    @POST("video/")
    Call<ResponseBody> upload(
            @Query("student_id") String id,
            @Query("user_name") String name,
            @Part List<MultipartBody.Part> parts);
}
