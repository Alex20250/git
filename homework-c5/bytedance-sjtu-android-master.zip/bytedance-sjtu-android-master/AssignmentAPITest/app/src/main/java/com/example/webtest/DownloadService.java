package com.example.webtest;

import com.example.webtest.bean.VideoInfo;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;

public interface DownloadService {

    @GET("video/")
    Call<VideoInfo> download();
}
