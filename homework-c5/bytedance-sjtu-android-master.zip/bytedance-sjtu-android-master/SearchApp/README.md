## Chapter 2 Coursework

- 基于RecyclerView实现了一个搜索列表页
- 由SearchBar中的文本内容会对Displayed View Content进行过滤
- 点击任意列表项会通过Intent跳转至相应的ItemActivity页面
- 单击取消会finish整个Activity

![img1](folder/screenShot01.png)

![img2](folder/screenShot02.png)

![img3](folder/screenShot03.png)

![img4](folder/screenShot04.png)