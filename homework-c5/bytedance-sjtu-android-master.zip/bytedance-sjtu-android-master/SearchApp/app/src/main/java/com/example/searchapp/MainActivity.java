package com.example.searchapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

import com.example.searchapp.definedlayout.SearchLayout;
import com.example.searchapp.rycomponent.SearchAdapter;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView mRecycleView = findViewById(R.id.cy_id);
        SearchAdapter mSearchAdapter = new SearchAdapter();
        mRecycleView.setLayoutManager(new LinearLayoutManager(this));
        mRecycleView.setAdapter(mSearchAdapter);

        List<String> data = new ArrayList<>();
        for (int i = 0; i < 100; i += 1) {
            data.add("这是第" + i + "行");
        }
        mSearchAdapter.notifyItems(data);

        SearchLayout mSearchLayout = findViewById(R.id.search_id);
        mSearchLayout.addTextChangedListener(new SearchLayout.OnSearchTextChangeListener() {
            @Override
            public void afterChangedCB(String text) {
                List<String> filterData = new ArrayList<>();
                for (String s : data) {
                    if (s.contains(text)) {
                        filterData.add(s);
                    }
                }

                mSearchAdapter.notifyItems(filterData);
            }
        });
    }
}