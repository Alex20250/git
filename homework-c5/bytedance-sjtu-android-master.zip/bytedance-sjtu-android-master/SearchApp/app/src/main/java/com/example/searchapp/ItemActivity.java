package com.example.searchapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        TextView mTextView = findViewById(R.id.item_text_id);
        mTextView.setText(getIntent().getStringExtra("extra"));
    }
}