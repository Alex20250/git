### Chapter 3 Coursework

- 完成lottie动画，支持手动修改和自动播放
- 属性动画练习：添加Scale和Fade动画至AnimatorSet
- 使用ViewPager和Fragment实现一个简单的好友列表界面

![img1](folder/img1.png)

![img2](folder/img2.png)

![img3](folder/img3.png)

