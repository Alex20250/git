package com.example.uploadservice.listener;

/**
 * Description：
 * Created by kang on 2018/3/29.
 */

public interface PhotoAlbumListener<T> {
    void onSelected(T t);

    void onClickCamera();
}
